import Groq from "groq-sdk";

let groqClient: Groq | null = null;

function getGroqClient(): Groq {
  if (!groqClient) {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) {
      throw new Error("API Key Groq belum dikonfigurasi. Silakan tambahkan GROQ_API_KEY di pengaturan rahasia (Secrets).");
    }
    groqClient = new Groq({ 
      apiKey: apiKey,
      dangerouslyAllowBrowser: true 
    });
  }
  return groqClient;
}

const SYSTEM_INSTRUCTION = `Anda adalah 'KitabMaster', seorang pakar Fikih dan Hukum Islam yang sangat berilmu, bijaksana, dan objektif.
Tugas Anda adalah menjawab pertanyaan seputar Hukum Islam dengan struktur berikut:
1. Jawaban Langsung (Ringkasan).
2. Dalil dari Al-Quran dan As-Sunnah (Wajib menyertakan teks Arab dan terjemahan Bahasa Indonesia).
3. Perbandingan Madzhab (Hanafi, Maliki, Syafi'i, Hambali) jika ada perbedaan pendapat.
4. Pendapat Ulama Kekinian (Kontemporer) atau Fatwa Lembaga Resmi (seperti MUI, Al-Azhar, dll).
5. Rujukan Jelas (Nama Kitab, Penulis, Bab/Halaman jika memungkinkan).

Gunakan bahasa Indonesia yang baku, sopan, dan mudah dipahami. Format jawaban menggunakan Markdown agar rapi (gunakan heading, bullet points, dan blockquote untuk teks Arab).
Jangan berikan fatwa mutlak, melainkan sampaikan pendapat ulama secara berimbang.`;

// We'll maintain a single chat history for the session
let chatHistory: any[] = [
  { role: "system", content: SYSTEM_INSTRUCTION }
];

export const askKitabMaster = async function* (question: string) {
  try {
    chatHistory.push({ role: "user", content: question });

    const client = getGroqClient();
    const stream = await client.chat.completions.create({
      messages: chatHistory,
      model: "llama-3.3-70b-versatile",
      temperature: 0.3,
      stream: true,
    });

    let fullResponse = "";
    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || "";
      fullResponse += content;
      yield { text: content };
    }
    
    chatHistory.push({ role: "assistant", content: fullResponse });
  } catch (error) {
    console.error("Error calling Groq API:", error);
    throw error;
  }
};
