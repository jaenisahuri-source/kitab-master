import React from "react";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { User, BookOpen } from "lucide-react";

interface ChatMessageProps {
  role: "user" | "assistant";
  content: string;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ role, content }) => {
  const isUser = role === "user";

  return (
    <div
      className={`flex w-full ${isUser ? "justify-end" : "justify-start"} mb-6`}
    >
      <div
        className={`flex max-w-[85%] ${isUser ? "flex-row-reverse" : "flex-row"} items-start gap-4`}
      >
        {/* Avatar */}
        <div
          className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
            isUser
              ? "bg-[#5A5A40] text-white"
              : "bg-white border border-[#e2e8f0] text-[#5A5A40]"
          }`}
        >
          {isUser ? <User size={20} /> : <BookOpen size={20} />}
        </div>

        {/* Message Bubble */}
        <div
          className={`px-6 py-4 rounded-2xl shadow-sm ${
            isUser
              ? "bg-[#5A5A40] text-white rounded-tr-none"
              : "bg-white text-gray-800 rounded-tl-none border border-[#e2e8f0]"
          }`}
        >
          {isUser ? (
            <p className="whitespace-pre-wrap">{content}</p>
          ) : content === "" ? (
            <div className="flex items-center gap-2 h-6">
              <div
                className="w-2 h-2 bg-[#5A5A40] rounded-full animate-bounce"
                style={{ animationDelay: "0ms" }}
              ></div>
              <div
                className="w-2 h-2 bg-[#5A5A40] rounded-full animate-bounce"
                style={{ animationDelay: "150ms" }}
              ></div>
              <div
                className="w-2 h-2 bg-[#5A5A40] rounded-full animate-bounce"
                style={{ animationDelay: "300ms" }}
              ></div>
            </div>
          ) : (
            <div className="markdown-body text-sm md:text-base">
              <Markdown
                remarkPlugins={[remarkGfm]}
                components={{
                  blockquote: ({ node, ...props }) => {
                    // Check if blockquote contains Arabic text (heuristic: contains Arabic characters)
                    const text = React.Children.toArray(props.children).join(
                      "",
                    );
                    const hasArabic = /[\u0600-\u06FF]/.test(text);

                    if (hasArabic) {
                      return (
                        <blockquote
                          className="arabic-text"
                          dir="rtl"
                          {...props}
                        />
                      );
                    }
                    return <blockquote {...props} />;
                  },
                }}
              >
                {content}
              </Markdown>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
