import React, { useState, useRef, useEffect } from "react";
import { BookOpen, AlertCircle } from "lucide-react";
import { ChatMessage } from "./components/ChatMessage";
import { ChatInput } from "./components/ChatInput";
import { askKitabMaster } from "./services/groqService";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Assalamu'alaikum warahmatullah wabarakatuh. Saya KitabMaster, asisten Anda untuk tanya jawab Fikih dan Hukum Islam. Silakan tanyakan masalah yang ingin Anda ketahui, insya Allah saya akan menjawab berdasarkan Al-Quran, As-Sunnah, perbandingan madzhab, dan pendapat ulama kekinian beserta rujukannya.",
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
    };
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    setError(null);

    const assistantMessageId = (Date.now() + 1).toString();
    setMessages((prev) => [
      ...prev,
      { id: assistantMessageId, role: "assistant", content: "" },
    ]);

    try {
      const stream = await askKitabMaster(content);

      for await (const chunk of stream) {
        const chunkText = (chunk as any).text || "";
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === assistantMessageId
              ? { ...msg, content: msg.content + chunkText }
              : msg,
          ),
        );
      }
    } catch (err: any) {
      console.error("Error in chat:", err);
      setError(
        err.message ||
          "Terjadi kesalahan saat memproses pertanyaan Anda. Silakan coba lagi.",
      );
      // Remove the empty assistant message if it failed completely
      setMessages((prev) => {
        const newMessages = [...prev];
        const lastMsg = newMessages[newMessages.length - 1];
        if (lastMsg.id === assistantMessageId && lastMsg.content === "") {
          newMessages.pop();
        }
        return newMessages;
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#f5f5f0] font-sans">
      {/* Header */}
      <header className="bg-white border-b border-[#e2e8f0] py-4 px-6 shadow-sm z-10">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <div className="w-10 h-10 bg-[#5A5A40] text-white rounded-xl flex items-center justify-center shadow-sm">
            <BookOpen size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 font-serif">
              KitabMaster
            </h1>
            <p className="text-xs text-gray-500 font-medium tracking-wide uppercase">
              Tanya Jawab Hukum Islam
            </p>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="max-w-4xl mx-auto">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} role={msg.role} content={msg.content} />
          ))}

          {error && (
            <div className="flex items-center gap-2 text-red-600 bg-red-50 p-4 rounded-xl mb-6 max-w-[85%] ml-14 border border-red-100">
              <AlertCircle size={20} />
              <p className="text-sm">{error}</p>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer className="bg-white border-t border-[#e2e8f0] p-4">
        <div className="max-w-4xl mx-auto">
          <ChatInput onSend={handleSendMessage} disabled={isLoading} />
          <p className="text-center text-xs text-gray-400 mt-3">
            KitabMaster dapat membuat kesalahan. Harap verifikasi informasi
            penting dengan ulama atau ustadz terpercaya.
          </p>
        </div>
      </footer>
    </div>
  );
}
